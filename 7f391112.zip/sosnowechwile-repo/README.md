# Sosnowe Chwile repo

## Struktura
- `frontend/` — pliki GitHub Pages
- `backend/` — Node.js + Express + Nodemailer

## GitHub Pages
W ustawieniach Pages wskaż folder `frontend/` jako źródło publikacji jeśli używasz deployu przez folder root albo skopiuj zawartość `frontend/` do root publikacyjnego.

## Backend
1. Wybierz hosting dla folderu `backend/`.
2. Skonfiguruj zmienne środowiskowe z `.env.example`.
3. Uruchom `npm install` i `npm start`.
